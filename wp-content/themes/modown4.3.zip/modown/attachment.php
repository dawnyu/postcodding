<?php
/**
 * The template for displaying attachments
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 */