<?php 
    //by mobantu.com
	echo '1';